# Test plan

## Unit tests for diagnostic rules
- Each symptom returns the expected safe next steps.
- Unanswered checks reduce evidence completeness.
- Unknown answers are not treated as yes/no evidence.
- Reports never claim that a specific component is broken.
- Report labels do not say "real scan" when only user answers were collected.

## Android USB tests
- Android phone without USB host support: capability is limited; enumeration returns empty/error without claiming TV fault.
- No cable connected: empty device list; report says no peripheral exposed.
- USB storage connected: appears as a peripheral, but is not identified as a TV.
- Phone connected to TV USB-A port: verify real-world behavior; expect many setups to expose no useful peripheral.
- USB permission is not required for descriptor-only enumeration, but must be implemented if future protocol work needs interface access.
- Verify no data is written and no commands are sent.

## iOS tests
- App reports generic USB host discovery unsupported.
- No device is labelled connected unless a supported accessory integration confirms it.
- Supported External Accessory integration, if later added, must be tested against documented protocol strings and physical accessories.

## Visual diagnostic tests
- Ask test participants to report known examples of lines, color cast, flicker, dead pixel, source-only black screen and TV-wide black screen.
- Compare results with TV's built-in picture test and multiple inputs.
- Record false positives/false negatives.
- Camera banding, reflections, moiré and compression artifacts must be documented as possible confounders if photo/video analysis is added.

## Release gates
- No unsupported claim that USB alone fixes a TV.
- No model-specific compatibility claim without physical verification.
- Clear privacy notice and consent before photo/video capture.
- Manufacturer support / professional service recommended for suspected internal hardware faults.
