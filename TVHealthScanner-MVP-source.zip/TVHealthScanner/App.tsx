import React, {useEffect, useMemo, useState} from 'react';
import {SafeAreaView, ScrollView, Text, View, Pressable, Platform, ActivityIndicator} from 'react-native';
import {getUsbCapability, enumerateUsbDevices, UsbCapability, UsbDeviceInfo} from './src/native/usb';
import {buildReport, CheckAnswer, Symptom, SYMPTOMS, CHECKS, DiagnosticReport} from './src/diagnostics/engine';

const colors = {bg:'#0b1020', panel:'#151d31', panel2:'#1d2942', text:'#f4f7ff', muted:'#a7b4ce', accent:'#70d6ff', warning:'#ffcc80', good:'#91e6b3', border:'#2c3b58'};
type Screen = 'home'|'scan'|'report';

export default function App() {
  const [screen,setScreen] = useState<Screen>('home');
  const [symptom,setSymptom] = useState<Symptom>('lines');
  const [answers,setAnswers] = useState<Record<string,CheckAnswer>>({});
  const [capability,setCapability] = useState<UsbCapability|null>(null);
  const [devices,setDevices] = useState<UsbDeviceInfo[]>([]);
  const [usbBusy,setUsbBusy] = useState(false);
  const [usbError,setUsbError] = useState<string|null>(null);
  const [report,setReport] = useState<DiagnosticReport|null>(null);

  useEffect(() => { getUsbCapability().then(setCapability).catch(() => setCapability({
    platform:Platform.OS, genericUsbHostDiscovery:false, status:'error', message:'Could not read platform capability status.'
  })); }, []);

  const currentChecks = useMemo(() => CHECKS.filter(c => c.symptoms.includes(symptom)), [symptom]);

  async function scanUsb() {
    setUsbBusy(true); setUsbError(null);
    try {
      const result = await enumerateUsbDevices();
      setDevices(result.devices);
      if (result.error) setUsbError(result.error);
      if (!result.devices.length && !result.error) setUsbError('No USB peripherals were exposed to the app. This does not prove the TV is faulty.');
    } catch (e) {
      setUsbError(e instanceof Error ? e.message : 'USB enumeration failed.');
    } finally { setUsbBusy(false); }
  }

  function startScan(s: Symptom) {
    setSymptom(s); setAnswers({}); setReport(null); setScreen('scan');
  }

  function finish() {
    const r = buildReport(symptom, answers, capability, devices);
    setReport(r); setScreen('report');
  }

  const button = (label:string, onPress:()=>void, secondary=false) => (
    <Pressable onPress={onPress} style={{padding:14,borderRadius:12,background:secondary?colors.panel2:colors.accent,marginTop:10,alignItems:'center'}}>
      <Text style={{color:secondary?colors.text:'#06111d',fontWeight:'700'}}>{label}</Text>
    </Pressable>
  );

  const card = (children:React.ReactNode) => <View style={{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:16,padding:16,marginTop:12}}>{children}</View>;
  const title = (t:string) => <Text style={{color:colors.text,fontSize:23,fontWeight:'800',marginBottom:8}}>{t}</Text>;
  const body = (t:string) => <Text style={{color:colors.muted,fontSize:14,lineHeight:21}}>{t}</Text>;

  return <SafeAreaView style={{flex:1,backgroundColor:colors.bg}}>
    <ScrollView contentContainerStyle={{padding:18,paddingBottom:40}}>
      <Text style={{color:colors.accent,fontSize:12,fontWeight:'800',letterSpacing:2}}>TV HEALTH SCANNER</Text>
      <Text style={{color:colors.text,fontSize:30,fontWeight:'900',marginTop:5}}>TV diagnostics</Text>
      <Text style={{color:colors.muted,marginTop:5}}>USB capability checks + guided visual diagnosis</Text>

      {screen === 'home' && <>
        {card(<>
          {title('USB connection status')}
          {capability ? <>
            <Text style={{color:capability.genericUsbHostDiscovery?colors.good:colors.warning,fontWeight:'800',marginBottom:6}}>
              {capability.genericUsbHostDiscovery?'USB host enumeration may be available':'Generic TV USB diagnostics are not available on this platform'}
            </Text>
            {body(capability.message)}
          </> : <ActivityIndicator color={colors.accent}/>}
          {body('A detected USB device is not necessarily a TV and does not mean the TV exposes diagnostic commands. The app does not write to connected devices.')}
          {button(usbBusy?'Checking USB…':'Check USB connection',scanUsb,true)}
          {usbError ? <Text style={{color:colors.warning,marginTop:10}}>{usbError}</Text>:null}
          {devices.map((d,i)=><View key={`${d.vendorId}-${d.productId}-${i}`} style={{paddingVertical:8,borderTopWidth:1,borderColor:colors.border,marginTop:8}}>
            <Text style={{color:colors.text,fontWeight:'700'}}>USB peripheral {i+1}</Text>
            {body(`Vendor ID: ${d.vendorId} · Product ID: ${d.productId}`)}
            {body(`Device: ${d.productName || 'Name not provided'} · Manufacturer: ${d.manufacturerName || 'Not provided'}`)}
            {body('Compatibility: unknown — no supported TV diagnostic protocol has been verified.')}
          </View>)}
        </>)}
        {card(<>
          {title('What problem do you see?')}
          {body('Choose the closest symptom. The app will guide you through safe checks and report observations, not claim an unverified hardware diagnosis.')}
          {SYMPTOMS.map(s=>button(s.label,()=>startScan(s.id),true))}
        </>)}
      </>}

      {screen === 'scan' && <>
        {button('← Back to dashboard',()=>setScreen('home'),true)}
        {card(<>
          {title(`Check: ${SYMPTOMS.find(s=>s.id===symptom)?.label}`)}
          {body('If possible, also open the TV’s built-in settings/menu. Do not open the TV casing or change service-menu settings.')}
          {currentChecks.map((c,index)=><View key={c.id} style={{paddingVertical:14,borderTopWidth:index?1:0,borderColor:colors.border}}>
            <Text style={{color:colors.text,fontWeight:'700',fontSize:16}}>{index+1}. {c.question}</Text>
            {body(c.why)}
            <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:10}}>
              {(['yes','no','unknown'] as CheckAnswer[]).map(a=><Pressable key={a} onPress={()=>setAnswers(prev=>({...prev,[c.id]:a}))} style={{paddingVertical:9,paddingHorizontal:12,borderRadius:10,backgroundColor:answers[c.id]===a?colors.accent:colors.panel2}}>
                <Text style={{color:answers[c.id]===a?'#06111d':colors.text,fontWeight:'700'}}>{a==='yes'?'Yes':a==='no'?'No':'Not sure'}</Text>
              </Pressable>)}
            </View>
          </View>)}
          {button('Generate diagnostic report',finish)}
        </>)}
      </>}

      {screen === 'report' && report && <>
        {button('← New scan',()=>setScreen('home'),true)}
        {card(<>
          {title('Diagnostic report')}
          <Text style={{color:colors.warning,fontWeight:'800',fontSize:16}}>{report.summary}</Text>
          {body(`Report ID: ${report.id}`)}
          {body(`Platform: ${report.platform} · Symptom: ${report.symptomLabel}`)}
          {body(`Evidence completeness: ${report.evidenceCompleteness}%`)}
          <View style={{marginTop:12,padding:12,backgroundColor:colors.panel2,borderRadius:12}}>
            <Text style={{color:colors.text,fontWeight:'800'}}>What this means</Text>
            {body(report.interpretation)}
          </View>
          <Text style={{color:colors.text,fontWeight:'800',marginTop:16,marginBottom:6}}>Observations</Text>
          {report.observations.map((o,i)=><Text key={i} style={{color:colors.muted,marginTop:5}}>• {o}</Text>)}
          <Text style={{color:colors.text,fontWeight:'800',marginTop:16,marginBottom:6}}>Recommended next steps</Text>
          {report.recommendations.map((r,i)=><Text key={i} style={{color:colors.muted,marginTop:5}}>{i+1}. {r}</Text>)}
          <Text style={{color:colors.text,fontWeight:'800',marginTop:16,marginBottom:6}}>Limitations</Text>
          {report.limitations.map((l,i)=><Text key={i} style={{color:colors.muted,marginTop:5}}>• {l}</Text>)}
          {button('Back to dashboard',()=>setScreen('home'),true)}
        </>)}
      </>}
      <Text style={{color:'#6e7d99',fontSize:11,marginTop:20,lineHeight:17}}>This app is a screening aid. It cannot confirm internal component failure without compatible diagnostic access or professional testing.</Text>
    </ScrollView>
  </SafeAreaView>;
}
