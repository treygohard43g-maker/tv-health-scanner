import {NativeModules, Platform} from 'react-native';

export type UsbCapability = {
 platform:string;
 genericUsbHostDiscovery:boolean;
 status:'available'|'unsupported'|'error'|'limited';
 message:string;
};
export type UsbDeviceInfo = {
 vendorId:number;productId:number;manufacturerName?:string|null;productName?:string|null;deviceName?:string|null;
};
type UsbResult = {devices:UsbDeviceInfo[];error?:string};
type NativeUsbModule = {
 getCapability():Promise<UsbCapability>;
 enumerateDevices():Promise<UsbResult>;
};
const NativeUSB = NativeModules.TVUsbDiagnostics as NativeUsbModule|undefined;

export async function getUsbCapability():Promise<UsbCapability> {
 if (Platform.OS==='ios') {
   return NativeUSB?.getCapability ? NativeUSB.getCapability() : {
    platform:'ios',genericUsbHostDiscovery:false,status:'unsupported',
    message:'iOS apps cannot generally enumerate arbitrary USB host devices such as TVs. A compatible accessory protocol or manufacturer-supported integration would be required.'
   };
 }
 if (Platform.OS==='android') {
   return NativeUSB?.getCapability ? NativeUSB.getCapability() : {
    platform:'android',genericUsbHostDiscovery:true,status:'limited',
    message:'Android USB host enumeration can be available on compatible phones. It only lists peripherals exposed by Android and does not establish TV diagnostic compatibility.'
   };
 }
 return {platform:Platform.OS,genericUsbHostDiscovery:false,status:'unsupported',message:'This platform is not supported by this build.'};
}

export async function enumerateUsbDevices():Promise<UsbResult> {
 if (Platform.OS!=='android') return {devices:[],error:'Generic USB device enumeration is not available in this app on iOS. No TV diagnostic scan was performed.'};
 if (!NativeUSB) return {devices:[],error:'Android native USB module is not installed. See native/android/INTEGRATION.md.'};
 return NativeUSB.enumerateDevices();
}
