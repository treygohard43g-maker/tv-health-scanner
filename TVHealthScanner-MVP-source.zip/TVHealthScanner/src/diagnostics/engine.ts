import {Platform} from 'react-native';
import {UsbCapability, UsbDeviceInfo} from '../native/usb';

export type Symptom = 'lines'|'flicker'|'color'|'black'|'freeze'|'pixels'|'blur';
export type CheckAnswer = 'yes'|'no'|'unknown';
export const SYMPTOMS:{id:Symptom;label:string}[] = [
 {id:'lines',label:'Lines across the screen'},
 {id:'flicker',label:'Flickering or flashing'},
 {id:'color',label:'Incorrect or distorted colors'},
 {id:'black',label:'Black screen or no picture'},
 {id:'freeze',label:'Picture freezes or glitches'},
 {id:'pixels',label:'Stuck or dead pixels'},
 {id:'blur',label:'Blurry picture'}
];
export type Check = {id:string;symptoms:Symptom[];question:string;why:string};
export const CHECKS:Check[] = [
 {id:'menu_lines',symptoms:['lines'],question:'Do the lines also appear over the TV home menu or settings?',why:'If yes, the problem may be inside the TV or its image processing. This alone cannot identify a specific component.'},
 {id:'source_lines',symptoms:['lines'],question:'Do the lines appear with more than one input or source?',why:'If only one source is affected, investigate that source and its cable first.'},
 {id:'menu_flicker',symptoms:['flicker'],question:'Does the TV menu flicker as well as video content?',why:'This helps separate TV-wide behavior from a source-specific issue.'},
 {id:'power_flicker',symptoms:['flicker'],question:'Does the flicker continue after a normal restart and checking power connections?',why:'Persistent flicker can have several causes and may need professional testing.'},
 {id:'pattern_color',symptoms:['color'],question:'Are colors distorted on the TV menu and on multiple sources?',why:'A problem across multiple sources suggests a TV setting or TV-side issue, but does not prove hardware failure.'},
 {id:'settings_color',symptoms:['color'],question:'Have you checked picture mode, color temperature, and accessibility/color settings?',why:'Incorrect settings can mimic display faults.'},
 {id:'menu_black',symptoms:['black'],question:'Can you see the TV home menu or volume indicator?',why:'A visible menu suggests the display is producing an image and the source/input may be the issue.'},
 {id:'audio_black',symptoms:['black'],question:'Can you hear audio or see status lights while the screen is black?',why:'Audio/status behavior provides context but cannot diagnose a backlight or panel by itself.'},
 {id:'restart_freeze',symptoms:['freeze'],question:'Does the problem persist after a normal restart?',why:'A restart can clear temporary software issues. Do not factory reset without backing up settings and understanding consequences.'},
 {id:'apps_freeze',symptoms:['freeze'],question:'Does freezing happen in more than one app or input?',why:'A single app or source may be responsible.'},
 {id:'pixel_fixed',symptoms:['pixels'],question:'Does the same tiny dot stay in exactly the same place on different images?',why:'A fixed dot may be a pixel defect; image compression and camera artifacts can look similar.'},
 {id:'pixel_pattern',symptoms:['pixels'],question:'Have you checked a full-screen red, green, blue, white, and black image?',why:'Solid-color patterns help locate suspected pixel defects. This app does not automatically measure pixels in this MVP.'},
 {id:'source_blur',symptoms:['blur'],question:'Does the blur happen with the TV menu and multiple sources?',why:'If menus are sharp but one source is blurry, investigate source resolution and signal quality.'},
 {id:'resolution_blur',symptoms:['blur'],question:'Have you checked source resolution, picture sharpness, and motion settings?',why:'Source scaling and picture settings can affect perceived sharpness.'}
];

export type DiagnosticReport = {
 id:string;createdAt:string;platform:string;symptom:Symptom;symptomLabel:string;
 summary:string;interpretation:string;evidenceCompleteness:number;
 observations:string[];recommendations:string[];limitations:string[];
 usbStatus:string;usbDeviceCount:number;
};

const LIMITATIONS = [
 'No internal TV hardware access was confirmed by this scan.',
 'USB enumeration does not prove a connected device is a TV or supports a diagnostic protocol.',
 'The report is based on user answers and available platform capability information.',
 'The app cannot repair physical panel damage or confirm a specific failed component.'
];

export function buildReport(symptom:Symptom, answers:Record<string,CheckAnswer>, cap:UsbCapability|null, devices:UsbDeviceInfo[]):DiagnosticReport {
 const symptomMeta = SYMPTOMS.find(s=>s.id===symptom)!;
 const checks = CHECKS.filter(c=>c.symptoms.includes(symptom));
 const answered = checks.filter(c=>answers[c.id] && answers[c.id] !== 'unknown');
 const observations = checks.map(c=>{
   const a=answers[c.id];
   return `${c.question} — ${a==='yes'?'Yes':a==='no'?'No':a==='unknown'?'Not sure':'Not answered'}`;
 });
 const recommendations = recommendationsFor(symptom, answers);
 let interpretation = 'Insufficient evidence to narrow down the cause. Complete the checks and compare the TV’s built-in menu with multiple inputs where possible.';
 if (symptom==='lines' && answers.menu_lines==='yes') interpretation='Because lines are reported over the TV menu, a TV-side display or processing issue is possible. This does not identify the panel, T-Con, cable, or main board as the cause.';
 else if (symptom==='lines' && answers.menu_lines==='no') interpretation='If lines occur only on selected content or inputs, the source device, cable, or signal path is a reasonable first area to investigate.';
 else if (symptom==='black' && answers.menu_black==='yes') interpretation='A visible menu means the display can show at least some image content. Check the selected input, source device, and cable before assuming hardware failure.';
 else if (symptom==='black' && answers.menu_black==='no') interpretation='If no menu or status overlay is visible, the cause remains uncertain. Power, backlight, panel, and internal electronics may require manufacturer-guided or professional testing.';
 else if (symptom==='color' && answers.pattern_color==='yes') interpretation='Color distortion across menus and multiple sources suggests a TV-side setting or processing issue, but a hardware fault is not confirmed.';
 else if (symptom==='freeze' && answers.apps_freeze==='no') interpretation='If only one app or input freezes, investigate that app, source device, or connection before attributing the fault to the TV.';
 else if (symptom==='pixels' && answers.pixel_fixed==='yes') interpretation='A fixed dot is consistent with a possible pixel defect. Confirm using solid-color patterns and another source; this app has not automatically verified individual pixels.';
 const completeness = checks.length ? Math.round(answered.length/checks.length*100) : 0;
 return {
  id:`TVR-${Date.now().toString(36).toUpperCase()}`,createdAt:new Date().toISOString(),platform:Platform.OS,
  symptom,symptomLabel:symptomMeta.label,summary:completeness===100?'Checks completed — review findings':'Preliminary screening — more evidence needed',
  interpretation,evidenceCompleteness:completeness,observations,recommendations,limitations:LIMITATIONS,
  usbStatus:cap?.status ?? 'unknown',usbDeviceCount:devices.length
 };
}

function recommendationsFor(s:Symptom,a:Record<string,CheckAnswer>):string[] {
 const common = ['Run the TV manufacturer’s built-in picture test if available.','Compare the TV menu with at least two sources or inputs, if practical.','Record the TV model number and the conditions when the fault occurs.'];
 if(s==='lines') return [a.menu_lines==='yes'?'Arrange manufacturer support if lines remain visible over the built-in menu.':'Check the affected source, cable, and input first.','Try a normal restart and inspect external cables without forcing connectors.',...common];
 if(s==='flicker') return ['Check power and signal connections safely.','Disable recently changed picture/motion settings temporarily to compare.',...common];
 if(s==='color') return ['Restore ordinary picture settings or compare another picture mode.','Check color/accessibility settings and source output format.',...common];
 if(s==='black') return ['Check power/status indicators and selected input.','Try the TV remote’s home/menu button and a known-working source.','Do not open the TV; persistent no-picture symptoms may require service.'];
 if(s==='freeze') return ['Restart the TV normally.','Check whether the issue affects one app, all apps, or external inputs.','Check official firmware updates for the exact model; avoid unofficial firmware.'];
 if(s==='pixels') return ['Use full-screen solid-color patterns to check whether the dot remains fixed.','Avoid pressure, rubbing, or heat-based “pixel repair” methods.','Check the manufacturer warranty/dead-pixel policy if the defect persists.'];
 return ['Check source resolution and picture settings.','Compare built-in menus and another source.',...common];
}
