package com.tvhealthscanner.usb

import android.content.Context
import android.hardware.usb.UsbManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class TVUsbDiagnosticsModule(private val context: ReactApplicationContext) :
  ReactContextBaseJavaModule(context) {
  override fun getName() = "TVUsbDiagnostics"

  @ReactMethod
  fun getCapability(promise: Promise) {
    val result = Arguments.createMap()
    result.putString("platform", "android")
    result.putBoolean("genericUsbHostDiscovery", true)
    result.putString("status", "limited")
    result.putString("message", "Android may enumerate attached USB peripherals on supported phones. This does not mean a connected TV exposes a diagnostic protocol.")
    promise.resolve(result)
  }

  @ReactMethod
  fun enumerateDevices(promise: Promise) {
    try {
      val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
      val devices = Arguments.createArray()
      manager.deviceList.values.forEach { device ->
        val item = Arguments.createMap()
        item.putInt("vendorId", device.vendorId)
        item.putInt("productId", device.productId)
        item.putString("manufacturerName", device.manufacturerName)
        item.putString("productName", device.productName)
        item.putString("deviceName", device.deviceName)
        devices.pushMap(item)
      }
      val result = Arguments.createMap()
      result.putArray("devices", devices)
      promise.resolve(result)
    } catch (e: Exception) {
      promise.reject("USB_ENUMERATION_FAILED", "Could not enumerate USB peripherals.", e)
    }
  }
}
