# Android native module integration

1. Copy the Kotlin files into `android/app/src/main/java/com/tvhealthscanner/usb/`.
2. Ensure the package declaration matches the folder.
3. Register the package in `MainApplication.kt` by adding `TVUsbDiagnosticsPackage()` to the packages list, following the React Native template for your installed version.

Example (the exact template varies by React Native version):

```kotlin
override fun getPackages(): List<ReactPackage> =
  PackageList(this).packages.apply {
    add(TVUsbDiagnosticsPackage())
  }
```

4. Add the optional USB host feature declaration to `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-feature android:name="android.hardware.usb.host" android:required="false" />
```

This module only enumerates attached USB devices. It does not claim a device is a TV, does not request permission to read/write endpoints, and does not send commands. For actual communication, implement a separately reviewed, model-specific protocol only after obtaining public documentation and verifying compatibility on real hardware.
