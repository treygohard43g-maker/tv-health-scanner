#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(TVUsbDiagnostics, NSObject)
RCT_EXTERN_METHOD(getCapability:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(enumerateDevices:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
@end
