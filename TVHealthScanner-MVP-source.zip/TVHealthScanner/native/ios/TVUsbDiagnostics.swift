// Capability boundary for iOS.
//
// Register this as a React Native native module if desired. This deliberately does
// not claim arbitrary USB host discovery. ExternalAccessory is for supported
// accessories/protocols and is not a universal TV diagnostic interface.
//
// Implement an adapter only for a documented, supported accessory protocol and
// devices that Apple permits the app to communicate with.

import Foundation
import React
import ExternalAccessory

@objc(TVUsbDiagnostics)
class TVUsbDiagnostics: NSObject {
  @objc
  func getCapability(_ resolve: RCTPromiseResolveBlock,
                     rejecter reject: RCTPromiseRejectBlock) {
    resolve([
      "platform": "ios",
      "genericUsbHostDiscovery": false,
      "status": "unsupported",
      "message": "iOS does not provide generic enumeration of arbitrary USB host devices such as TVs to ordinary apps. A compatible supported accessory protocol or manufacturer integration is required."
    ])
  }

  @objc
  func enumerateDevices(_ resolve: RCTPromiseResolveBlock,
                        rejecter reject: RCTPromiseRejectBlock) {
    resolve([
      "devices": [],
      "error": "Generic USB device enumeration is not available on iOS in this app. No TV diagnostic scan was performed."
    ])
  }

  @objc static func requiresMainQueueSetup() -> Bool { false }
}
