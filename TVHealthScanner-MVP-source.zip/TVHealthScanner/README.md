# TV Health Scanner — MVP source

Cross-platform React Native + TypeScript MVP for a Smart TV diagnostic assistant.

## Important capability boundary
This release does **not** claim that an ordinary USB cable can diagnose any TV. It:
- reports platform-level USB capability honestly;
- on Android, enumerates attached USB devices and reports descriptors only when Android exposes them;
- does not send undocumented commands to TVs or attempt firmware/service-menu operations;
- on iOS, reports that generic USB host discovery of arbitrary TVs is not available to this app. A supported, documented accessory protocol would need a separate integration;
- provides guided visual checks and creates a report from user-observed symptoms.

A USB device appearing in Android's list is not proof that it is a TV or that it supports diagnostics.

## Requirements
- Node.js 20+
- React Native environment (Expo is not sufficient for the native Android USB module in this project)
- Android Studio / Android SDK for Android
- Xcode on macOS for iOS builds
- For iOS, CocoaPods as required by the installed React Native version

## Install
This source is an app-layer/native-module implementation intended to be copied into a React Native Community CLI project matching the version in `package.json`. React Native native project templates change over time, so generate the native shell with the current official React Native CLI first, then copy/merge these files.

```bash
npm install
```

## Run
Use the current React Native Community CLI instructions to build the Android/iOS native shell. Android USB support is registered via `MainApplication` as described in `native/android/INTEGRATION.md`. iOS registers a capability module that intentionally reports unsupported generic USB host discovery.

## Diagnostic behavior
1. User chooses a symptom.
2. The app presents safe checks.
3. User records whether each check passed, failed, or could not be completed.
4. Report labels observations separately from suspected causes.
5. Confidence is a heuristic based on evidence completeness, not a medical-style or hardware certainty score.

## Android USB notes
- The app requests permission before reading descriptors.
- No vendor/product IDs are hard-coded as "supported TV models".
- No data is written to connected devices.
- Most TV USB ports are host ports intended for storage/accessories; connecting a phone may not establish a useful data channel.
- Android USB host API can only enumerate peripherals that the phone's USB host stack exposes.

## iOS notes
iOS does not provide a general-purpose API for arbitrary USB host enumeration by ordinary apps. External Accessory is for compatible accessories using supported protocols; it is not a universal interface to TVs. The iOS module therefore reports this limitation instead of pretending to scan.

## Security and privacy
- No cloud account is required.
- Reports remain in app memory in this MVP; persistence can be added explicitly.
- Photos are not collected in this release.
- Never tell users to open a TV service menu, short pins, flash firmware, or open the TV enclosure based only on app results.

## Testing checklist
See `docs/TEST_PLAN.md`.
